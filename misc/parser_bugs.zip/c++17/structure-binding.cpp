// Structure binding is not support

#include<iostream>

int a[2] = {1, 2};

// x y doesn't appear in struct panel
auto [x, y] = a; // int x = a[0]; int y = a[1];

struct S {
	int c;
	int d;
} s = {1, 2};

auto& [z, w] = s; // same as above

int main() {
	// output 1 2
	std::cout << x << ' ' << y << std::endl;
}