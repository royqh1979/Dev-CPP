// Deduction guide for CTAD not supported.

template<typename T>
class Ptr {
private:
	T p;

public:
	using PtrType = T;
	
	template<typename U>
	Ptr(U& t) : p{&t} { }
};

// Doesn't appeared in struct panel
template<typename U>
Ptr(U& u) -> Ptr<decltype((&u))>; 

int main() {
	int a;
	Ptr x{a};
	decltype(x)::PtrType p; // int*
}
