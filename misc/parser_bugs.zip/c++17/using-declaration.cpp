// Multiple name in using declaration is not supported

#include <iostream>

// Only cin is appeared in struct panel
using std::cin, std::cout, std::endl;

int main() {
	int a;
	cin >> a;  // hover on cin shows info
	cout << a; // hover on cout doesn't show info
}
