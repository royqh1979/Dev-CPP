// ADL (Argument-Dependent name Lookup) not supported.

#include <iostream>

namespace Ns {
	struct A {
		operator int() { return 0; }
	};
	
	void f(const A& a) {
		std::cout << "inside namespace" << std::endl;
	}
}

void f(int) {
	std::cout << "outside namespace" << std::endl;
}

int main() {
	Ns::A a;
	// f should be Ns::f not ::f
	f(a); // hover message is wrong, should be 'void f(const A& a)'
	// should output "inside namespace"
}
