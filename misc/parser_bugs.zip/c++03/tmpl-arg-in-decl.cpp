// Template argument in declaration is buggy.

template<typename T, typename U>
struct A {
	static const int a = 4;
};

int b = A<int, int>::a; // An extra name 'int' appeared.

int main() { }
