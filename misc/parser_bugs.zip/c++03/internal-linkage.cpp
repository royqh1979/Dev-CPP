// namespace-scope const-qualified variables have internal linkage.

int externVar;          // external linkage, marked as 'g' in panel
static int staticVar;   // internal linkage, marked as 'v' in panel
const int constVar = 1; // should be internal linkage ('v'), but 'g'

// Note that this feature is C++-specific;
// C language treat const-qualified var as external linkage.

int main() { }
