// Some C bugs also exists in C++.
#include <cstdlib>

// complicate declarations
int (*ptrToArr)[3];
int (*(foo)(double))[3];
int *a, (*b)[3];
int *c, (*d)(void);

// cv-qualified ptr
int* const e = NULL, * const f = NULL;

// digraphs
int arr<:3:> = <% 1, 2, 3 %>;

// volatile qualifier
int volatile vi;
int const volatile cvi = 0;

int main() { }

// typedef bugs
int typedef Int; 
