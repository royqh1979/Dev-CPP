// Most vexing parse

struct A {
	A() { }
	A(int) { }
	int data;
};
int main() {
	// a is parsed as a variable, but it should be a function.
	A a();
	// press a. will show suggestions of member 'data'
	// but a.data will cause compilation error.
	// a.data;
	
	// b is also a function not a variable.
	double x = 1.0;
	A b(int(x));
	// c is also a function not a variable.
	A c(A());
}
