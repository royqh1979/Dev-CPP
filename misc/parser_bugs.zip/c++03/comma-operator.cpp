// comma-operator-overload is not well parsed.
struct A { };
struct B { };
struct C { };

C operator+(const A&, const B&) {
    return C();
}
// missing 'operator' in structure panel
C operator,(const A&, const B&) {
    return C();
}

int main() {
    A a; B b; C c;
    c = a + b;
    c = (a, b);
    // 'operator,' doesn't show in suggestion list
}
