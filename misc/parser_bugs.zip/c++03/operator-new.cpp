// Operator new is treated differently from other operator overload function.
#include <cstdlib>

struct A {
	A operator+(const A&);
	void* operator new(std::size_t);
};

// operator+ definition is located in 'A' struct
A A::operator+(const A&) {
	return A();
}
// but operator new is located outsize with a name 'new'
void* A::operator new(std::size_t c) {
	return std::malloc(c);
}
// operator delete has same problem.

int main() { }
