// Alternative tokens not parsed correctly.

// ra not shown in structure panel
int a = 2;
int bitand ra = a;  // lvalue-reference
// int and rra = 2; // rvalue-reference

// ~A() parsed as A()
struct A {
	A() { }         // constructor
	compl A() { }   // destructor
};

int main() { }
