// Diamond inheritance without virtual should have 2 instance of base class

struct A {
	int data;
};
struct B : A { };
struct C : A { };
struct D : B, C {
	// should have 2 'data' member here, B::data and C::data
	void f() {
		// data; // ambigious name
		B::data;
		C::data;
	}
};

int main() { }
