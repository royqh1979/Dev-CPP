// restrict keyword is not recognized.
int* restrict a;
void f(int a[restrict]) { }
void g(int* restrict a) { }

// When declaring cvr-qualified pointer after sth,
// restrict will be recognized as an identifier.
int b, *restrict c;

int main(void) { }
