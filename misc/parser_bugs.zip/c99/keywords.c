// C99 keywords not fully highlighted.

_Bool boolVar; // Keyword _Bool
double _Complex complexVar; // Keyword _Complex
// _Imaginary not implement in GCC
int* restrict a; // Keyword restrict

_Pragma("pack()"); // _Pragma should be a preprocessor token

int main(void) { }
