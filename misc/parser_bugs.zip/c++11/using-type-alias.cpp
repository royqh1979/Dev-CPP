// using type alias not supported
using Int = int;  // Int not shown in structure panel
typedef int Int2; // but typedef is (partially) OK

int main() {
	Int a;
}
