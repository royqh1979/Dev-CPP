// C++11 raw string not well supported

// ")\";\nint x;" is part of str, x shouldn't appear in struct panel
const char str[] = R"*()";
int x;
)*";

int main() {
	// x; // should not defined
}
