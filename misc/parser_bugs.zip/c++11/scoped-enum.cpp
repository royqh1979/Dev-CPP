// scoped-enum not supported.
enum class Enum { // Enum name shouldn't contain 'class'
	Item1, Item2, Item3 // Enum item name is scoped, not global
};

int main() {
	Enum e = Enum::Item1;
	// Enum e = Item1; // Compilation error
}
