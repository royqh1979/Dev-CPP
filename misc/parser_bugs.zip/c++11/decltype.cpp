// decltype not supported
struct A {
	int data;
};

A a;
decltype(a) b; // not parsed

int main() {
	b.data;
}
