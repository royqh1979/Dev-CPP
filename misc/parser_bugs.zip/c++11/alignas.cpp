// alignas specifier not supported.

// Wrongly parsed below struct as a function named 'alignas(8)'.
struct alignas(8) A { };

int main() {
	A a;
}
