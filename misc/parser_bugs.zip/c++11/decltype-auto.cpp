// decltype-auto not supported

auto a = 1;
decltype(auto) b = 1; // b doesn't appear in struct panel

int main() {}
