// user-defined-literal (operator"") is not well supported.
struct A {
	unsigned long long data;
};

// This function has a name 'operator+' in structure panel
A operator+(const A& a1, const A& a2) {
	return A{a1.data + a2.data};
}
// but this function is missing 'operator', just a '_A'
A operator""_A(unsigned long long x) {
	return A{x};
}

int main() {
	A a = 56_A + 42_A;
}
