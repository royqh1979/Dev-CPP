// deleted implicit member function shouldn't appear in structure panel.
// struct 'A' should be empty.
struct A {
	A() = delete;
	A(const A&) = delete;
};
int main() { }
