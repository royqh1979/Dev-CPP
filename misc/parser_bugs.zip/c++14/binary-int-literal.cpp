// Wrong tokenize for binary-integer-literal

int hex = 0x0;
int oct = 00;
int bin = 0b0; // b0 should have same color as above

int main() {}
