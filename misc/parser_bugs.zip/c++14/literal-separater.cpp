// Wrong tokenize for some int literal separator

// decimal literal parsed correctly...
int dec = 123'456;
// while hex literal parsed wrong.
int hex = 0x123'456;

int main() {}
