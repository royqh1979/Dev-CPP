// Namespace with attribute cannot be parsed correctly.

// OK
namespace Ns1 {
	int x;
}

// Ns2 parsed as globle variable, while all declarations below it are ignored.
namespace [[deprecated]] Ns2 {
	int x;
}
// main function not shown in struct panel
int main() {}