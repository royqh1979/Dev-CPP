// enum item with attribute is ill-parsed.

enum E1 {
	a1,
	b1,
	c1
};

// [[deprecated]] attr shouldn't be parsed as part of enum item
enum E2 {
	a2 [[deprecated]],
	b2 [[deprecated]],
	c2 [[deprecated]]
};

int main() {}