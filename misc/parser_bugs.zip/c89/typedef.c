/* A is recognize as a typedef... */
typedef int A;

/* But this will be ill-parsed. B should be a type. */
int typedef B;

/* And all declaration before it will be parsed wrong. */

int main(void) {
	A a;
	B b; /* a and b unexpectedly appeared in the panel. */
}
