/* Use C++ keywords as identifiers cause error. */

/* These variables doesn't appear in structure panel. */
int and;
int and_eq;
int bitand;
int bitor;
int compl;
int constexpr;
int const_cast;
int delete;
int dynamic_cast;
int explicit;
int export;
int false;
int mutable;
int new;
int noexcept;
int not;
int not_eq;
int or;
int or_eq;
int reinterpret_cast;
int static_assert;
int static_cast;
int template;
int this;
int thread_local;
int throw;
int true;
int try;
int typename;
int virtual;
int xor;
int xor_eq;

int main(void) { }

// These variable breaks parsing.
int alignas;
int alignof;
int decltype;
int typeid;
