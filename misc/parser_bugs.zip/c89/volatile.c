/* volatile qualifier sometimes not recognized. */

/* d, f, g is not shown in structure panel. */
const int a;
int const b;
volatile int c;
int volatile d;
const volatile int e;
const int volatile f;
int const volatile g;
volatile const int h;
volatile int const i;
const int volatile j;

int main(void) {}
