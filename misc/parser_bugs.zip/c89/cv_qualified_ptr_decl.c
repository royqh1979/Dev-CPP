/* Declaring cv-qualified pointers is buggy. */

/* These are OK but... */
int* const a;
int* const b;

/* declare them in one line will cause problem. */
int* const c, * const d; 
/* const keyword is recognized as an identifier
   and a strange "__STATEMENT__x" thing */

int main(void) { }
