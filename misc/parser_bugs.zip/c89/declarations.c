/* These identifiers are appeared in structure panel... */
int* ptr;
int arr[3];
int (*ptrToFunc)(void);

/* But this is not. */
int (*ptrToArr)[3];

/* ...or any complicate form declaration */
int (*(*foo)(double))[3];

/* ...or very strange result */
int *a, (*b)[3];
int *c, (*d)(void);

int main(void) { }
