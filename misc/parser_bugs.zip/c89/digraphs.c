/* Digraphs not supported */
#define a 1  /* OK */
%:define b 2 /* Not recognized */

#include <stdlib.h>
%:include <stdlib.h> /* unclickable */

int x[3] = {
	1, 2, 3
};
int y<:3:> = <%
	1, 2, 3  /* 2 and 3 is parsed as var */
%>;
int z<:1:> = <%
	1 & 2    /* a strange "__STATEMENT__x" thing */
%>;

int main(void) {
	int x = a, y = b;
}
