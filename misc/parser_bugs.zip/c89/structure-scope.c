/* No structure scope in C. */

/* ITEM1 and ITEM2 are both file-scope identifiers. */
enum { ITEM1 };

struct S {
	enum { ITEM2 };	
};

int item1 = ITEM1; /* OK */
int item2 = ITEM2; /* No suggestion, wrong tokenization */

int main(void) {}
