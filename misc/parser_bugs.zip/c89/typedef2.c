/* typdef bugs also exists in anonymous struct declaration. */
typedef struct {
	int data;
} A;

/* Type B is ill-parsed as variable "typedef B" */
struct {
	int data;
} typedef B;

int main(void) {
	A a;
	B b;
}
