/* Old-style-function-definition not supported. */

/* c is a parameter of f, but wrongly parsed as a global variable. */
void f(a,b,c)
int a, b;char c;
{ }

int main(void) {
	f(1, 2, 'a');
}
