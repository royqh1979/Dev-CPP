/* A function returning anonymous struct will be parsed as a variable. */
#include <stdlib.h>

struct { int data; }* f(void) {
	return NULL;
}

int main(void) {
	f;   /* In the structure panel, f is marked as "global var". */
	f();
}
