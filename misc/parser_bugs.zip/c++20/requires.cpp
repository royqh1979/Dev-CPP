// requires expr in requires clause is wrongly parsed as function

template<typename T>
concept Addend = requires (T t){
	t + t;
}; // requires expr, OK

template<typename T> requires Addend<T> // requires clause, OK
void f(const T& t) {}


// But requires expr in requires clause will cause 
// parser recognized requires expr as a function
template<typename T> requires requires (T t){
	t + t;
} 
void g(const T& t) {}

int main() {
	f(1);
	g(1);
//	f("");
//	g("");
}
