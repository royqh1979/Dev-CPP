// _Atomic specifier cause parsing error.
_Atomic(int) a; // a doesn't appeared in structure panel
_Atomic int b;  // but _Atomic qualifier doesn't cause error

int main(void) { }
