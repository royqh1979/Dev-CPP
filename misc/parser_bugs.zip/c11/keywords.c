// C11 keywords not highlighted.
#include <math.h>
#include <stdlib.h>

// Keyword _Alignas
struct S {
	_Alignas(16) float data[4];
};

// Keyword _Alignof
int size = _Alignof(struct S);

// Keyword _Atomic
_Atomic int a;

// Keyword _Noreturn
_Noreturn void f(void) { 
	exit(0);
}

// Keyword _Static_assert
_Static_assert(1, "");

// Keyword _Thread_local
_Thread_local int b;

// Keyword _Generic
typedef double (*FuncType)(double);
int main(void) {
	FuncType f = _Generic(1.0, double: sqrt, float: sqrtf);
	f(1.0);
}
